﻿namespace MISA.HUST._21H._2022.API.Controllers
{
    class Constant
    {
        public static string CONNECTION_STRING = "Server=3.0.89.182;Port=3306;Database=daotao.ai.2022.thvuong;Uid=dev;Pwd=12345678;";
    }
}